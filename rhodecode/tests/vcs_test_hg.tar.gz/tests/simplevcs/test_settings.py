# Empty django settings module

