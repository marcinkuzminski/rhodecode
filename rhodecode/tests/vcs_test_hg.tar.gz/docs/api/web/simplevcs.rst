.. _api-web-simplevcs:

Simple VCS
==========

.. automodule:: vcs.web.simplevcs

Models
------

.. automodule:: vcs.web.simplevcs.models
   :members:

Views
-----

.. automodule:: vcs.web.simplevcs.views
   :members:

.. automodule:: vcs.web.simplevcs.views.hg
   :members:

