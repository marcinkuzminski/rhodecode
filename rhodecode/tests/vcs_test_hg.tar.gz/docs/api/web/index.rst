.. _api-web:

Web
===

.. automodule:: vcs.web

Django extension
----------------

.. toctree::
   :maxdepth: 2

   simplevcs

