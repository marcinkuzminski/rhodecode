.. _api-backends:

Backends
========

.. module:: vcs.backends

Base Backend
------------

.. automodule:: vcs.backends.base
   :members:

Implemented Backends
--------------------

.. toctree::
   :maxdepth: 1

   hg

