"""
Django pluggable appliation build on top of ``vcs``.
"""

